from genero import Genero

class Pelicula:

    def __init__(self, titulo: str, generos: list[Genero],  duracion: int) -> None:
        self.titulo = titulo
        self.generos = generos
        self.duracion = duracion

    

     
