from enum import Enum

class Genero(Enum):
    ACCION = 'Acción'
    COMEDIA = 'Comedia'
    DRAMA = 'Drama'
    
        
